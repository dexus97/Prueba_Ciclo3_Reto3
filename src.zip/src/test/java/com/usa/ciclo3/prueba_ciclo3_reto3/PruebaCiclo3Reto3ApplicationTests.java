package com.usa.ciclo3.prueba_ciclo3_reto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaCiclo3Reto3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
