package com.usa.ciclo3.prueba_ciclo3_reto3.crudrepository;

import com.usa.ciclo3.prueba_ciclo3_reto3.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRespository extends CrudRepository <Client, Integer> {
}
