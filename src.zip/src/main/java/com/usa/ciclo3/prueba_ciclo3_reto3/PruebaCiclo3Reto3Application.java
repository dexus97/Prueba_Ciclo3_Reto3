package com.usa.ciclo3.prueba_ciclo3_reto3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaCiclo3Reto3Application {

    public static void main(String[] args) {
        SpringApplication.run(PruebaCiclo3Reto3Application.class, args);
    }

}
